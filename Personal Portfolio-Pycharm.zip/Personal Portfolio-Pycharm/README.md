Name = ____________________
Student ID = ________________________

This is a personal porfolio website which describes all my achievement. I have created one route with Django which redirects to another Projects page.